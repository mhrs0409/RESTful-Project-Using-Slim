<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app = new \Slim\App;

// Get All Phones
$app->get('/api/phones', function(Request $request, Response $response){
    
    $sql = "SELECT * FROM phones";

    try{
        //Get DB Object
        $db = new db();
        //Connect
        $db = $db->connect();

        $stmt = $db->query($sql);
        $phones = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db = null;
        echo json_encode($phones);

    } catch(PDOException $e){
        echo '{"error": {"text": '.$e->getMessage().'}';

    }

});
    // Get Single Phones
$app->get('/api/phone/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    
    $sql = "SELECT * FROM phones WHERE id = $id";

    try{
        //Get DB Object
        $db = new db();
        //Connect
        $db = $db->connect();

        $stmt = $db->query($sql);
        $phones = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db = null;
        echo json_encode($phones);

    } catch(PDOException $e){
        echo '{"error": {"text": '.$e->getMessage().'}';

    }
});
   // Add Phones
   $app->post('/api/phone/add', function(Request $request, Response $response){
    $owner_name = $request->getParam('owner_name');
    $cont_num = $request->getParam('cont_num');
    $brand = $request->getParam('brand');
    
    $sql = "INSERT INTO phones (owner_name,cont_num,brand) VALUES (:owner_name,:cont_num,:brand)";

    try{
        //Get DB Object
        $db = new db();
        //Connect
        $db = $db->connect();

        $stmt = $db->prepare($sql);

        $stmt->bindParam(':owner_name',$owner_name);
        $stmt->bindParam(':cont_num',$cont_num);
        $stmt->bindParam(':brand',$brand);

        $stmt->execute();

        echo '{"notice": {"text": "phones was Added"}';

    } catch(PDOException $e){
        echo '{"error": {"text": '.$e->getMessage().'}';

    }
});
   // Update Phones
   $app->put('/api/phone/update/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $owner_name = $request->getParam('owner_name');
    $cont_num = $request->getParam('cont_num');
    $brand = $request->getParam('brand');
    
    $sql = "UPDATE phones SET
                owner_name = :owner_name,
                cont_num = :cont_num,
                brand = :brand
            WHERE id = $id";

    try{
        //Get DB Object
        $db = new db();
        //Connect
        $db = $db->connect();

        $stmt = $db->prepare($sql);

        $stmt->bindParam(':owner_name',$owner_name);
        $stmt->bindParam(':cont_num',$cont_num);
        $stmt->bindParam(':brand',$brand);

        $stmt->execute();

        echo '{"notice": {"text": "phones was Updated"}';

    } catch(PDOException $e){
        echo '{"error": {"text": '.$e->getMessage().'}';

    }
});
    // Delete Phones
    $app->delete('/api/phone/delete/{id}', function(Request $request, Response $response){
        $id = $request->getAttribute('id');
        
        $sql = "DELETE FROM phones WHERE id = $id";
    
        try{
            //Get DB Object
            $db = new db();
            //Connect
            $db = $db->connect();
    
            $stmt = $db->prepare($sql);
            $stmt->execute();
            $db = null;
    
            echo '{"notice": {"text": "phones was Deleted"}';

        } catch(PDOException $e){
            echo '{"error": {"text": '.$e->getMessage().'}';
    
        }
    });
